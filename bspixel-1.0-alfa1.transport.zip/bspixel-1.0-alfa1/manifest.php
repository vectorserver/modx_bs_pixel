<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5b59e8b2f18fdec042070e15e6b5c62f',
      'native_key' => 'bspixel',
      'filename' => 'modNamespace/bc4851c641a85ea12f6a609195248e5a.vehicle',
      'namespace' => 'bspixel',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '30dc174a62450a6f08995fba5a83b87b',
      'native_key' => 47,
      'filename' => 'modPlugin/893fb4606753a2311ac9529cdac34b58.vehicle',
      'namespace' => 'bspixel',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8c64e4d1cc9f4a41571949a3c4b15592',
      'native_key' => 1,
      'filename' => 'modCategory/4c49ee430068eb80739bd6b7f05d2eec.vehicle',
      'namespace' => 'bspixel',
    ),
  ),
);